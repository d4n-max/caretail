---
name: CareTail Premium Mobile System
colors:
  surface: '#f4fafd'
  surface-dim: '#d4dbdd'
  surface-bright: '#f4fafd'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eef5f7'
  surface-container: '#e8eff1'
  surface-container-high: '#e2e9ec'
  surface-container-highest: '#dde4e6'
  on-surface: '#161d1f'
  on-surface-variant: '#3d4948'
  inverse-surface: '#2b3234'
  inverse-on-surface: '#ebf2f4'
  outline: '#6c7a78'
  outline-variant: '#bcc9c7'
  surface-tint: '#006a65'
  primary: '#006a65'
  on-primary: '#ffffff'
  primary-container: '#4ecdc4'
  on-primary-container: '#00544f'
  inverse-primary: '#5dd9d0'
  secondary: '#ae2f34'
  on-secondary: '#ffffff'
  secondary-container: '#ff6b6b'
  on-secondary-container: '#6d0010'
  tertiary: '#6d5e00'
  on-tertiary: '#ffffff'
  tertiary-container: '#d1ba46'
  on-tertiary-container: '#564a00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#7cf6ec'
  primary-fixed-dim: '#5dd9d0'
  on-primary-fixed: '#00201e'
  on-primary-fixed-variant: '#00504c'
  secondary-fixed: '#ffdad8'
  secondary-fixed-dim: '#ffb3b0'
  on-secondary-fixed: '#410006'
  on-secondary-fixed-variant: '#8c1520'
  tertiary-fixed: '#fbe36a'
  tertiary-fixed-dim: '#dec651'
  on-tertiary-fixed: '#211b00'
  on-tertiary-fixed-variant: '#524600'
  background: '#f4fafd'
  on-background: '#161d1f'
  surface-variant: '#dde4e6'
typography:
  display-lg:
    fontFamily: Montserrat
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Montserrat
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Montserrat
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Montserrat
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-lg:
    fontFamily: Montserrat
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.5px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  unit: 8px
  margin-mobile: 24px
  gutter-mobile: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
  section-padding: 32px
---

## Brand & Style
The design system is centered on a "Sophisticated Sanctuary" aesthetic. It balances the emotional warmth required for pet care with the precision of a high-end health tracking utility. The style moves away from typical "cute" pet app tropes, opting instead for a **Corporate / Modern** framework infused with **Minimalist** warmth. 

The visual language emphasizes clarity, calm, and organization to reduce the cognitive load of pet management. Key characteristics include high-contrast typography for accessibility, ample whitespace to suggest a premium experience, and subtle tactile elements like soft gradients that provide a sense of depth and polish without feeling cluttered.

## Colors
The palette is designed to evoke a sense of professional care and vitality. 

- **Primary (Turquoise):** Used for primary actions, progress indicators, and brand presence. It represents health and tranquility.
- **Secondary (Coral):** Reserved strictly for high-priority calls to action, urgent notifications, and critical highlights.
- **Background (Warm Cream):** Replaces harsh whites to provide a softer, more "premium paper" feel that reduces eye strain.
- **Neutrals:** A deep slate (#2D3436) is used for text to ensure high contrast against the cream background while maintaining a softer look than pure black.
- **Gradients:** Use subtle linear gradients for primary buttons, moving from `#4ECDC4` to a slightly deeper teal to add a tactile, "pressable" quality.

## Typography
This design system utilizes a dual-font strategy to balance character with functionality.

- **Montserrat** is the display face, providing a geometric, modern, and confident tone for headers and titles. Its high x-height ensures a friendly yet structured appearance.
- **Inter** handles all body copy and UI labels. It is chosen for its exceptional legibility on small screens and its neutral, systematic nature which complements the expressive headers.
- **Contrast:** Ensure a minimum contrast ratio of 4.5:1 for body text. Title-level text should use the neutral slate color to maintain a grounded, premium feel.

## Layout & Spacing
Following Material 3 logic but with increased "breathing room" for a premium feel, this design system uses a **Fluid Grid** based on an 8dp square module.

- **Margins:** 24dp side margins on mobile to pull content inward, creating a more centered, curated look.
- **Vertical Rhythm:** Content blocks should be separated by 24dp or 32dp increments to reinforce a calm, uncrowded interface.
- **Safe Areas:** Adhere to system bars (status and navigation) with a minimum 16dp buffer for all interactive elements.
- **Grouping:** Use 8dp for related elements (e.g., a label and its input) and 16-24dp for unrelated groupings.

## Elevation & Depth
Depth is conveyed through **Ambient Shadows** and **Tonal Layering** rather than heavy borders.

- **Shadows:** Use highly diffused shadows with a slight tint of the brand color (e.g., `rgba(78, 205, 196, 0.08)`) to maintain warmth. Shadows should have a large blur radius (16-24px) and low Y-offset (4-8px) to suggest the element is floating just above the warm cream surface.
- **Tiers:** 
  - **Level 0 (Background):** The warm off-white base.
  - **Level 1 (Cards):** White (#FFFFFF) cards with subtle shadows.
  - **Level 2 (Overlays/Modals):** Floating elements with slightly more pronounced shadows and a backdrop dim of 40% black.
- **Transitions:** Use smooth, easing-in-out animations for elevation changes (e.g., a card lifting slightly when pressed).

## Shapes
The shape language is defined by "Soft Logic"—avoiding sharp corners entirely to maintain a friendly, approachable atmosphere.

- **Primary Cards:** Use a 24px corner radius. This large radius communicates a modern, subscription-grade quality.
- **Secondary Elements:** Smaller components like input fields or buttons should use a 16px radius.
- **Pill Shapes:** Use full-rounded pill shapes (999px) for chips, tags, and the primary CTA button to distinguish them from structural card elements.
- **Consistency:** Avoid mixing radius styles; the 24px "Large" radius is the signature of the design system.

## Components
Consistent styling across the app ensures a cohesive experience:

- **Buttons:** Primary buttons use the Turquoise gradient with white text. CTA buttons (Secondary) use the Coral color. All buttons are pill-shaped with a minimum height of 56dp for accessibility.
- **Cards:** White surfaces with a 24px radius. Use "Elegance Spacing" (20px internal padding) to ensure content doesn't feel cramped.
- **Input Fields:** Soft-filled fields (using `#F4F1EA`) with a 12px radius. On focus, the border transitions to a 2pt Turquoise stroke. Labels should always be visible (Material 3 "Outlined" style or "Floating" style).
- **Chips/Tags:** Used for pet categories or status (e.g., "Vaccinated"). These are pill-shaped with a low-opacity Turquoise background and Turquoise text.
- **Lists:** Clean, divider-less lists using white space and soft containers to separate items.
- **Progress Bars:** Thick, 8dp bars with rounded ends. Use Turquoise for progress and a very light version of Turquoise for the track.
- **Specialty Components:** Include "Pet Profile Quick-Switchers" (circular avatars with a 2pt Turquoise border when active) and "Timeline Cards" for tracking events.